function [initialIllu, FinalIllu, imgOut, denoisedImg] = main(img, mu, rho, ds, ss)

alpha = 0.08;
gamma = 0.8;

% lime 
% [FinalIllu, initialIllu] = lime(img, alpha, mu, rho, gamma)
temp = im2double(img);
% initialIllu = initialMap(temp);
[m,n,o] = size(temp);
initialIllu = zeros(m,n);
for i=1:m
    for j=1:n
        b = [temp(i,j,1), temp(i,j,2), temp(i,j,3)];
        if max(b) == 0
            initialIllu(i,j) = 0.0000001; %e
        else
            initialIllu(i,j) = max(b);
        end
    end
end

% refinedMap = lime_trial(initialIllu, alpha, mu, rho);
iter = 50;
Z = zeros(2*m, n);
G = Z;
W = weightMatrix(initialIllu, 5);

for i=1:iter
    U = Z/mu;
    A = (alpha*W)/mu;
    refinedMap = illuUpdate(initialIllu, mu, G, U);
%     G = shrinkage(A,(temp+U));
%     delIllu = multiplyd(refinedMap);
    [m1,n1] = size(refinedMap);
    DrmY = maked_alt(m);
    DrmX = maked_alt(n)';
    altIlluY = zeros(m+1,n);
    altIlluY(1:m1,1:n1) = refinedMap;
    altIlluY(m1+1, 1:n1-1) = refinedMap(1,2:n1);
    altIlluY(m+1,n) = refinedMap(1,1);

    delIlluY = DrmY*altIlluY;

    altIlluX = zeros(m1,n1+1);
    altIlluX(1:m,1:n) = refinedMap;
    altIlluX(1:m,n+1) = refinedMap(1:m,1);

    delIlluX = altIlluX*DrmX;

    tempx = reshape(delIlluX, [m1*n1,1]);
    tempy = reshape(delIlluY, [m1*n1,1]);
    temp3 = [tempx;tempy];
    delIllu = reshape(temp3,[2*m,n]);
    G = sign((delIllu+U)).*max((abs(delIllu+U)- A), zeros(size(alpha)));
    B = delIllu-G;
    Z = mu*(B+U);
    mu = mu*rho;
end

refinedMap = abs(refinedMap);
T_gamma = refinedMap.^gamma; %gamma correction

FinalIllu(:,:,1) = T_gamma;
FinalIllu(:,:,2) = T_gamma;
FinalIllu(:,:,3) = T_gamma;

imgOut = im2double(img)./FinalIllu;

denoisedImg = imbilatfilt(imgOut,ds,ss);

subplot(2,1,1);
imshow(img);
title("Original Image(low light)");

subplot(2,1,2);

imshow(imgOut);
title("Enhanced Image");







end
