function [updatedIllu] = illuUpdate(iniIllu, mu, G, U)

X= G-U;

% delX = multiplydtrans(X);
[p,n] = size(X);
m = floor(p/2);
x = reshape(X, [p*n,1]);
xx = reshape(x(1:m*n),[m,n]);
xy = reshape(x(m*n+1:p*n),[m,n]);

Dyi=maked_alt(m);
Dy=-Dyi; %size MxM
Dxi=maked_alt(n);
Dx=Dxi(1:n,1:n);
Dx(1:n,1)=Dx(1:n,1)+Dxi(1:n,n+1); %size NxN+1

%making Gy as size NxN+1
altGy=zeros(m+1,n);
altGy(2:m+1,1:n)=xy;
altGy(1,2:n)=xy(m,1:n-1);
altGy(1,1)=xy(m,n);

%calculating the gradients 
delGy=Dy*altGy;
delGx=xx*Dx;
delX=delGx+delGy;

numerator = 2*iniIllu + mu*delX;

illuNum = fftshift(fft2(numerator));
[m,n] = size(iniIllu);
% illudenom = Tdenom(m,n,mu);
dxe = zeros(m,n); %extended dx
dye = zeros(m,n); %extended dy
%acc. to horizontal and vertical gradient convolution kernels dx and dy
dxe(2,2) = -1;
dxe(2,3) = 1;
dye(2,2) = -1;
dye(3,2) = 1;

dxf=fftshift(fft2(dxe));
dxc=dxf.''; %conjugate
dx_mod=dxc.*dxf;

dyf=fftshift(fft2(dye));
dyc=dyf.'';
dy_mod=dyc.*dyf;

Td=2+mu*(dx_mod+dy_mod);

illumap = illuNum./Td;
updatedIllu = ifft2(ifftshift(illumap));
end