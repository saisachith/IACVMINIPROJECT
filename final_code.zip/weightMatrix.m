function [W] = weightMatrix(Illumap, kernelSize)

[m,n] = size(Illumap);
p = m*n;
% no of pixels

% obtaining gradient of illumap
% delIllumap = multiplyd(Illumap);
Dy = maked_alt(m);
Dx = maked_alt(n)';

altTy = zeros(m+1, n);
altTy(1:m,1:n) = Illumap;
altTy(m+1,1:n-1) = Illumap(1,2:n);
altTy(m+1,n) = Illumap(1,1);

delIlluY = Dy*altTy;

altTx=zeros(m,n+1);
altTx(1:m,1:n)=Illumap;
altTx(1:m,n+1)=Illumap(1:m,1);

delIlluX = altTx*Dx;

dtx = reshape(delIlluX, [p,1]);
dty = reshape(delIlluY, [p,1]);

delIllumap = [dtx;dty];
delIllumap = reshape(delIllumap, [2*m,n]);

dtvec = reshape(delIllumap,[2*p,1]);

dtx = dtvec(1:p);
dty = dtvec(p+1:2*p);

gaussianW = fspecial('gaussian',[kernelSize,1], 2);
xConv = conv(dtx, gaussianW, 'same');
yConv = conv(dty, gaussianW, 'same');

Wx = 1./(abs(xConv)+0.00001);
Wy = 1./(abs(yConv)+0.00001);

W = vertcat(Wx, Wy);
W = reshape(W, [2*m, n]);

end
